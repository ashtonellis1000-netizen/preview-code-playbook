
/**
 * Example Supabase Edge Function (Deno) to notify a shop of a new lead.
 * Deploy with: supabase functions deploy notify_new_lead
 */
import "jsr:@supabase/functions-js/edge-runtime.d.ts"

Deno.serve(async (req) => {
  const body = await req.json().catch(() => ({}))
  // TODO: send email / webhook to shop with body.shop_id + body.lead_id
  return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } })
})
