
-- ENUMS
create type visibility as enum ('public','followers','private');
create type verification_level as enum ('none','verified','elite');

-- USERS/SHOPS
create table public.shops (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  slug text unique not null,
  name text not null,
  description text,
  verification verification_level not null default 'none',
  avatar_url text,
  banner_url text
);

create table public.shop_members (
  user_id uuid not null references auth.users(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  role text not null default 'member',
  primary key (user_id, shop_id)
);

-- BUILDS
create table public.builds (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  title text not null,
  subtitle text,
  series text, -- optional collection
  visibility visibility not null default 'public'
);

create table public.build_shops (
  build_id uuid not null references public.builds(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  role text,
  verified boolean default false,
  primary key (build_id, shop_id)
);

create table public.build_media (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  build_id uuid not null references public.builds(id) on delete cascade,
  stage_index int not null default 0, -- horizontal carousel order
  media_type text not null check (media_type in ('image','video')),
  storage_path text not null,
  annotations jsonb default '{}'::jsonb -- draw overlay JSON
);

create table public.build_specs (
  build_id uuid primary key references public.builds(id) on delete cascade,
  horsepower int,
  torque int,
  zero_to_sixty_ms int,
  quarter_mile_ms int,
  dyno_sheet_url text,
  verified boolean default false
);

-- LEADS / JOBS
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  car text,
  service text,
  budget integer,
  status text not null default 'new' -- new, quoted, accepted, rejected
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  lead_id uuid references public.leads(id) on delete set null,
  title text,
  status text not null default 'in_progress', -- in_progress, completed, cancelled
  visibility visibility not null default 'private'
);

create table public.job_updates (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  storage_path text not null,
  annotations jsonb default '{}'::jsonb,
  note text
);

-- ANALYTICS
create table public.engagement_stats (
  shop_id uuid not null references public.shops(id) on delete cascade,
  day date not null,
  views integer not null default 0,
  likes integer not null default 0,
  saves integer not null default 0,
  shares integer not null default 0,
  quote_requests integer not null default 0,
  primary key (shop_id, day)
);

-- EVENTS & CLUBS
create table public.events (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  host_shop_id uuid references public.shops(id) on delete set null,
  name text not null,
  type text,
  starts_at timestamptz,
  location text,
  approved boolean default false
);

create table public.clubs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  visibility visibility not null default 'public',
  owner_shop_id uuid references public.shops(id) on delete set null
);

-- GARAGE & PURCHASES & REVIEWS
create table public.garage (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  visibility visibility not null default 'followers'
);

create table public.purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_id uuid not null references auth.users(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  text text not null
);

-- STORAGE BUCKETS (create via SQL for infra-as-code)
insert into storage.buckets (id, name, public) values
  ('build_media','build_media', true)
on conflict do nothing;

insert into storage.buckets (id, name, public) values
  ('job_updates','job_updates', false)
on conflict do nothing;

-- RLS
alter table public.shops enable row level security;
alter table public.shop_members enable row level security;
alter table public.builds enable row level security;
alter table public.build_shops enable row level security;
alter table public.build_media enable row level security;
alter table public.build_specs enable row level security;
alter table public.leads enable row level security;
alter table public.jobs enable row level security;
alter table public.job_updates enable row level security;
alter table public.engagement_stats enable row level security;
alter table public.events enable row level security;
alter table public.clubs enable row level security;
alter table public.garage enable row level security;
alter table public.purchases enable row level security;
alter table public.reviews enable row level security;

-- Simple policies (expand later)
create policy "public_read_shops" on public.shops for select using (true);
create policy "shop_members_manage_builds" on public.builds for all using (auth.uid() in (select user_id from public.shop_members sm where sm.shop_id = builds.shop_id));
create policy "public_read_public_builds" on public.builds for select using (visibility = 'public');
create policy "shop_members_manage_media" on public.build_media for all using (auth.uid() in (select user_id from public.shop_members sm join public.builds b on sm.shop_id=b.shop_id where b.id = build_media.build_id));
create policy "shop_members_manage_specs" on public.build_specs for all using (auth.uid() in (select user_id from public.shop_members sm join public.builds b on sm.shop_id=b.shop_id where b.id = build_specs.build_id));
create policy "shop_members_manage_leads" on public.leads for all using (auth.uid() in (select user_id from public.shop_members sm where sm.shop_id = leads.shop_id));
create policy "shop_members_manage_jobs" on public.jobs for all using (auth.uid() in (select user_id from public.shop_members sm where sm.shop_id = jobs.shop_id));
create policy "shop_members_manage_job_updates" on public.job_updates for all using (auth.uid() in (select user_id from public.shop_members sm where sm.shop_id = (select j.shop_id from public.jobs j where j.id = job_updates.job_id)));
create policy "public_read_verified_events" on public.events for select using (approved);
create policy "owner_read_garage" on public.garage for select using (auth.uid() = user_id);
