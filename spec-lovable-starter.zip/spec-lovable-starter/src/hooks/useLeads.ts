
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export function useLeads(shopId?: string) {
  return useQuery({
    queryKey: ['leads', shopId],
    enabled: !!shopId,
    queryFn: async () => {
      const { data, error } = await supabase.from('leads').select('*').eq('shop_id', shopId!).order('created_at', { ascending: false })
      if (error) throw error
      return data
    },
  })
}
