
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export function useEngagement(shopId?: string) {
  return useQuery({
    queryKey: ['engagement', shopId],
    enabled: !!shopId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('engagement_stats')
        .select('day, views, likes, saves, shares, quote_requests')
        .eq('shop_id', shopId!)
        .order('day', { ascending: true })
      if (error) throw error
      return data
    },
  })
}
