
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export function useBuilds() {
  return useQuery({
    queryKey: ['builds'],
    queryFn: async () => {
      const { data, error } = await supabase.from('builds').select('*').order('created_at', { ascending: false })
      if (error) throw error
      return data
    },
  })
}
