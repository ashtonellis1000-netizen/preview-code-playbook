
import { Routes, Route, Link } from 'react-router-dom'
import Feed from '@/pages/Feed'
import BuildDetails from '@/pages/BuildDetails'
import Dashboard from '@/pages/Dashboard'
import ShopProfile from '@/pages/ShopProfile'

export default function App() {
  return (
    <div className="min-h-screen">
      <nav className="sticky top-0 z-10 bg-neutral-950/70 backdrop-blur border-b border-neutral-800">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-4">
          <Link to="/" className="font-bold">SPEC</Link>
          <div className="ml-auto flex items-center gap-3">
            <Link to="/dashboard" className="text-sm text-neutral-300">Dashboard</Link>
            <Link to="/shop/spec-garage" className="text-sm text-neutral-300">Shop Profile</Link>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Feed />} />
        <Route path="/build/:id" element={<BuildDetails />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/shop/:slug" element={<ShopProfile />} />
      </Routes>
    </div>
  )
}
