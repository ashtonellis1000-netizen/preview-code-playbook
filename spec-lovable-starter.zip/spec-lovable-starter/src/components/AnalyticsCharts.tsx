
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts'

export default function AnalyticsCharts({ data }: { data: any[] }) {
  return (
    <div className="w-full h-64 bg-neutral-900 rounded-xl p-4">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="day" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="views" />
          <Line type="monotone" dataKey="quote_requests" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
