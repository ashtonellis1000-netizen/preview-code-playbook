
import { Link } from 'react-router-dom'
type Props = { build: any }
export default function BuildCard({ build }: Props) {
  return (
    <div className="w-full aspect-[9/16] bg-neutral-900 rounded-2xl overflow-hidden border border-neutral-800">
      <Link to={`/build/${build.id}`} className="block w-full h-full">
        <div className="h-2/3 bg-neutral-800 flex items-center justify-center">Media Placeholder</div>
        <div className="p-3 space-y-1">
          <div className="text-lg font-semibold line-clamp-1">{build.title}</div>
          <div className="text-sm text-neutral-400 line-clamp-2">{build.subtitle ?? ''}</div>
        </div>
      </Link>
    </div>
  )
}
