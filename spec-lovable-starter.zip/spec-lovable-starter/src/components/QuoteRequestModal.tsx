
export default function QuoteRequestModal() {
  return (
    <div className="p-4">
      <div className="text-lg font-semibold mb-2">Request a Quote</div>
      <form className="space-y-2">
        <input className="w-full p-2 rounded bg-neutral-800" placeholder="Your car (Year Make Model)" />
        <input className="w-full p-2 rounded bg-neutral-800" placeholder="Service needed" />
        <input className="w-full p-2 rounded bg-neutral-800" placeholder="Budget (optional)" />
        <button className="px-4 py-2 rounded bg-blue-600">Send</button>
      </form>
    </div>
  )
}
