
import { useRef, useState } from 'react'
import { ReactSketchCanvas } from 'react-sketch-canvas'

export default function UploadDrawer() {
  const canvasRef = useRef<ReactSketchCanvas>(null)
  const [file, setFile] = useState<File | null>(null)

  return (
    <div className="p-4 space-y-3">
      <input type="file" accept="image/*,video/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
      <div className="h-64 bg-neutral-800 rounded-xl overflow-hidden">
        <ReactSketchCanvas
          ref={canvasRef}
          width="100%"
          height="100%"
          strokeWidth={3}
          strokeColor="#00A3FF"
          className="bg-neutral-900"
        />
      </div>
      <button className="px-4 py-2 rounded-lg bg-blue-600">Save Annotated Media</button>
    </div>
  )
}
