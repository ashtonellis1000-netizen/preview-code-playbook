
import { useParams } from 'react-router-dom'

export default function BuildDetails() {
  const { id } = useParams()
  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <div className="h-96 bg-neutral-900 rounded-xl flex items-center justify-center">Horizontal Carousel Placeholder for Build {id}</div>
      <div className="bg-neutral-900 rounded-xl p-4 space-y-2">
        <div className="text-xl font-semibold">Performance Specs</div>
        <ul className="text-neutral-300 list-disc pl-6">
          <li>Horsepower: —</li>
          <li>0–60: —</li>
          <li>1/4 mile: —</li>
        </ul>
      </div>
    </div>
  )
}
