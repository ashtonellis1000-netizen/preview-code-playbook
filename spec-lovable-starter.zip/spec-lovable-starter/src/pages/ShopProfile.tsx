
export default function ShopProfile() {
  return (
    <div className="max-w-5xl mx-auto p-4 space-y-4">
      <div className="h-48 bg-neutral-900 rounded-xl" />
      <div className="text-2xl font-bold">Shop Name</div>
      <div className="text-neutral-300">Verified badge / tiers / links</div>
      <div className="grid grid-cols-2 gap-3">
        <div className="h-64 bg-neutral-900 rounded-xl" />
        <div className="h-64 bg-neutral-900 rounded-xl" />
      </div>
    </div>
  )
}
