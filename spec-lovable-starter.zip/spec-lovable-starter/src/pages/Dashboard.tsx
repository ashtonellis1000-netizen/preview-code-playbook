
import AnalyticsCharts from '@/components/AnalyticsCharts'
import { useEngagement } from '@/hooks/useEngagement'

export default function Dashboard() {
  const { data } = useEngagement('SHOP_ID_PLACEHOLDER')
  return (
    <div className="max-w-5xl mx-auto p-4 space-y-4">
      <div className="text-2xl font-bold">Shop Dashboard</div>
      <AnalyticsCharts data={data ?? []} />
      <div className="bg-neutral-900 rounded-xl p-4">Leads Table Placeholder</div>
    </div>
  )
}
