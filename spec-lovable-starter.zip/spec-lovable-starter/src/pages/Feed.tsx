
import { useBuilds } from '@/hooks/useBuilds'
import BuildCard from '@/components/BuildCard'

export default function Feed() {
  const { data } = useBuilds()
  return (
    <div className="max-w-sm mx-auto space-y-4 p-4">
      {(data ?? []).map((b) => <BuildCard key={b.id} build={b} />)}
    </div>
  )
}
