
# SPEC – Lovable-Ready Starter

This repository is designed to import cleanly into **Lovable** and preview the SPEC app with:
- TikTok-style **Feed** (`/`)
- Horizontal **Build Details** with performance specs (placeholder) (`/build/:id`)
- Shopify-style **Shop Dashboard** with charts and leads placeholder (`/dashboard`)
- **Shop Profile** page (`/shop/:slug`)
- **Supabase** client wired, with migrations and RLS policies prepared

## 1) Setup
1. Copy `.env.example` to `.env` and fill the values:
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
VITE_STRIPE_PUBLISHABLE_KEY=...
```
2. Install & run
```bash
npm install
npm run dev
```

## 2) Supabase Migrations
Run each SQL file in `supabase/migrations` via Supabase SQL editor or CLI.
Then enable RLS policies (already included in the SQL files).

## 3) Lovable Import
- Zip this folder and upload to Lovable.
- Lovable will detect Vite + React + TS with React Router and TanStack Query.
- The preview opens at `/` showing the feed and nav links.

## 4) Where to add real logic
- `src/hooks/` – Database fetching via Supabase and React Query.
- `src/components/UploadDrawer.tsx` – Draw-on annotations on uploaded media.
- `src/pages/Dashboard.tsx` – Charts fed from `engagement_stats` table.
- `src/pages/BuildDetails.tsx` – Horizontal carousel + chapters once you wire media data.

## 5) Notes
- Styling uses Tailwind. Keep the “black universe” background (#0a0a0a / Tailwind neutral-950) with blue accents.
- Stripe Connect setup is scaffolded in `src/lib/stripe.ts` (fill `VITE_STRIPE_PUBLISHABLE_KEY`).

