# SPEC Refiltered Master Plan

## 1. Main Layer – Feed and Build Experience

### TikTok-Style Discovery Feed
- **Vertical Scroll:** Users swipe vertically to browse new builds, similar to TikTok.
- **Horizontal Carousel:** Within each build, users swipe sideways to explore stages (Before → During → After). Each stage contains photos, clips, and annotations.
- **Engagement Controls:** Like, comment, save, request quote, share.

### Performance Stats Integration
- Specs module beneath each build:
  - Horsepower, torque, 0–60, 1/4 mile times.
  - Upload dyno sheets or verified PDFs for auto-generated “Verified Performance” badges.
- Supabase stores data in `build_specs` linked by `build_id`.

### Build Chapters / Series
- Each build can join a “Series” (e.g. Turbo Build, Wrap Install, Stage 3 Tune).
- Chapters appear as tappable progress markers at the bottom of a video.
- Functions like TikTok pinned collections or YouTube chapters.

### Picture & Video Upload + Draw-On Feature
- Shops upload or record media updates directly within SPEC.
- Integrated drawing tools let them circle, mark, or explain modifications.
- Client receives these as “progress stories.”
- When the job completes, the full collection becomes a public or private “Build Timeline.”

Client-side portal integrated in **Profile → Garage** for customers to:
- View progress.
- Approve next steps.
- Communicate with the shop.
- Retain a visual record of every modification.

---

## 2. Content Layer – Visibility and Promotion

### Verified Shops
- Anyone can post; verified shops earn boosted reach and a “Trusted Shop” badge.
- Verified content feeds into a separate, curated “Verified” feed.
- Verification earned through metrics, service quality, and consistent posting.

### Sponsored & Promoted Posts
- Stripe Connect for passive payments, supporting Apple Pay / Google Pay.
- Shops can pay to promote builds to target car segments or regions.

### TikTok Integration
- “Share to TikTok” button for fast reposting.
- Later: API-level integration to track clickbacks and conversions from TikTok to SPEC.

### Affiliate Postings *(Future Expansion)*
- Placeholder for affiliate links, partner brands, and commission tracking.

---

## 3. Following Layer – Community and Engagement

### Event Tab
- Shops and verified hosts can create meets, shows, or Cars & Coffee events.
- Users can RSVP, tag cars, upload photos.
- Supabase `events` table: name, type, date, location, host_shop_id, approved.

### Clubs
- Each club acts as a Reddit-style modern forum.
- Includes threads, polls, and post feeds.
- Can be public, invite-only, or shop-client-exclusive.

---

## 4. Personal Profile Layer – Ownership and Trust

### My Garage
- Users manage cars with modification lists.
- Visibility toggle: Public, Followers-only, or Private.

### Purchased List
- Auto-populated once a job is completed by a shop.
- Links to receipts, invoices, and build updates.

### Reviews
- Text-only reviews with optional reference links to build posts or videos.
- Media reviews reserved for future moderation-ready phases.

### Affiliate Dashboard *(Later Phase)*
- Users earn commissions on shared builds and part links once affiliate system launches.

---

## 5. Backend Layer – Infrastructure and Revenue

### Payment Integration
- Stripe Connect powers both one-time and recurring payments.
- Shops can authorize “tabs” for ongoing clients (detailing, maintenance, etc.).
- Supports Apple Pay, Google Pay, and standard cards.

### Supabase Edge Functions
Automations include:
- Job start → Notify client.
- Upload update → Notify client + log progress.
- Job completion → Push analytics + archive build.
- Daily analytics rollup to avoid view inflation.

### Public vs Paid Builds
- Free builds: public marketing content.
- Private builds: client-only view.
- Paid builds: premium paywall (viewer fee). SPEC earns 5–10% commission.

### Security & Access
- Row-Level Security ensures:
  - Shops only access their builds and clients.
  - Users only view their garage.
  - Verified-only privileges managed by admin tier.

---

## 6. Business Model & Expansion

### Immediate Revenue Streams
1. Stripe-boosted promoted posts.
2. Premium build paywalls.
3. Platform fee on job transactions.
4. Verified shop subscription tiers.

### Future Additions
- Live builds (Twitch-style streaming).
- Shop CRM Suite (quotes, job tracking, invoice automation).
- AI part recognition from media.

---

**SPEC Refiltered** = TikTok’s addictiveness + Shopify’s conversion clarity + LinkedIn’s credibility for performance and custom automotive culture.
